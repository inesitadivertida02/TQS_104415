package com.example.CarInfoSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarInfoSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
