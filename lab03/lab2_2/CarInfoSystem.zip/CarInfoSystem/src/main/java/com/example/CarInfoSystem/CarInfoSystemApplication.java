package com.example.CarInfoSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarInfoSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarInfoSystemApplication.class, args);
	}

}
